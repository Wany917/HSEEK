from SRC.Chargement import LoadCSV

from SRC.Statistique import PartieStat

from SRC.Filtrage import FiltrageFirstAndLastName, FiltrageAffichageApprenti, FiltrageAge, FiltrageNote

from SRC.Tri import *

from SRC.Menu import *



Data = LoadCSV("./DATA/data.csv")
LancementMenu(Data)
