def FiltrageFirstAndLastName(Data):
    TableauFirstName = []
    TableauLastName = []

    for Student in Data:
        TableauFirstName.append(Student.firstname)
        TableauLastName.append(Student.lastname)

    print("Choisissez le type de filtrage :")
    print("1. Filtrage par prénom")
    print("2. Filtrage par Nom de famille")
    print("3. Filtrage par prénoms et noms de famille")
    print("4. Filtrage par prénoms contenant une certaine chaîne de caractères")
    print("5. Filtrage par noms contenant une certaine chaîne de caractères")
    print("6. Filtrage par prénoms et noms contenant une certaine chaîne de caractères")
    print("7. Filtrage par prénoms commençant par une certaine chaîne de caractères ET noms contenant une certaine chaîne de caractères")
    print("8. Filtrage par prénoms ou noms finissant par une certaine chaîne de caractères")

    Choix = int(input("Entrez votre choix : "))

    if Choix == 1:
        SousChoix = int(input("Entrez le type de filtrage pour les prénoms : (1. Commencant par, 2. Finissant par)"))
        Caractere = input("Entrez le caractère pour le filtrage : ")
        if SousChoix == 1:
            Résultat = [Student for Student in Data if Student.firstname.startswith(Caractere)]
            return Résultat
        elif SousChoix == 2:
            Résultat = [Student for Student in Data if Student.firstname.endswith(Caractere)]
            return Résultat
        else:
            print("Choix invalide")

    elif Choix == 2:
        SousChoix = int(input("Entrez le type de filtrage pour les noms de famille : (1. Commencant par, 2. Finissant par)"))
        Caractere = input("Entrez le caractère pour le filtrage : ")
        if SousChoix == 1:
            Résultat = [Student for Student in Data if Student.lastname.startswith(Caractere)]
            return Résultat
        elif SousChoix == 2:
            Résultat = [Student for Student in Data if Student.lastname.endswith(Caractere)]
            return Résultat
        else:
            print("Choix invalide")

    elif Choix == 3:
        SousChoix = int(input("Entrez le type de filtrage pour les prénoms et noms de famille : (1. Commencant par, 2. Finissant par)"))
        Caractere = input("Entrez le caractère pour le filtrage : ")
        if SousChoix == 1:
            Résultat = [Student for Student in Data if Student.firstname.startswith(Caractere) and Student.lastname.startswith(Caractere)]
            return Résultat
        elif SousChoix == 2:
            Résultat = [Student for Student in Data if Student.firstname.endswith(Caractere) and Student.lastname.endswith(Caractere)]
            return Résultat
        else:
            print("Choix invalide")

    elif Choix == 4:
        Chaine = input("Entrez la chaîne pour filtrer les prénoms contenant : ")
        Résultat = [Student for Student in Data if Chaine in Student.firstname]
        return Résultat

    elif Choix == 5:
        Chaine = input("Entrez la chaîne pour filtrer les noms contenant : ")
        Résultat = [Student for Student in Data if Chaine in Student.lastname]
        return Résultat

    elif Choix == 6:
        Chaine = input("Entrez la chaîne pour filtrer les prénoms et noms contenant : ")
        Résultat = [Student for Student in Data if Chaine in Student.firstname and Chaine in Student.lastname]
        return Résultat

    elif Choix == 7:
        ChainePrenom = input("Entrez la chaîne pour filtrer les prénoms commençant par : ")
        ChaineNom = input("Entrez la chaîne pour filtrer les noms contenant : ")
        Résultat = [Student for Student in Data if Student.firstname.startswith(ChainePrenom) and ChaineNom in Student.lastname]
        return Résultat

    elif Choix == 8:
        Chaine = input("Entrez la chaîne pour filtrer les prénoms ou noms finissant par : ")
        Résultat = [Student for Student in Data if Chaine in Student.firstname or Chaine in Student.lastname]
        return Résultat

    else:
        print("Choix invalide")

def FiltrageAffichageApprenti(Data):

    TableauFirstName = []
    TableauLastName = []
    TableauApprentice = []

    for student in Data:
        TableauFirstName.append(student.firstname)
        TableauLastName.append(student.lastname)
        TableauApprentice.append(student.apprentice)

    print("Choisissez le statut d'apprenti à afficher :")
    print("1. Afficher les apprentis")
    print("2. Afficher les non-apprentis")

    Choix = int(input("Entrez votre choix : "))

    if Choix == 1:

        for i in range(len(TableauApprentice)):
            if TableauApprentice[i] == True:
                print(f"{TableauFirstName[i]} {TableauLastName[i]} est un apprenti")
    elif Choix == 2:
        for i in range(len(TableauApprentice)):
            if TableauApprentice[i] == False:
                print(f"{TableauFirstName[i]} {TableauLastName[i]} n'est pas un apprenti")
    else:
        print("Choix invalide")
        
def FiltrageAge(Data):
    TableauFirstName = []
    TableauLastName = []
    TableauAge = []

    for student in Data:
        TableauFirstName.append(student.firstname)
        TableauLastName.append(student.lastname)
        TableauAge.append(student.age)

    print("Choisissez le type de filtrage par âge :")
    print("1. Filtrer les étudiants ayant un âge inférieur ou égal à une certaine Valeur")
    print("2. Filtrer les étudiants ayant un âge supérieur ou égal à une certaine Valeur")
    print("3. Filtrer les étudiants ayant un âge compris entre deux valeurs")

    Choix = int(input("Entrez votre choix : "))

    if Choix == 1:
        AgeLimite = int(input("Entrez l'âge maximum : "))
        for i in range(len(TableauAge)):
            if TableauAge[i] <= AgeLimite:
                print(f"{TableauFirstName[i]} {TableauLastName[i]} a un âge inférieur à {AgeLimite} ans ({TableauAge[i]} ans) ")
    elif Choix == 2:
        AgeLimite = int(input("Entrez l'âge minimum : "))
        for i in range(len(TableauAge)):
            if TableauAge[i] >= AgeLimite:
                print(f"{TableauFirstName[i]} {TableauLastName[i]} a un âge supérieur à {AgeLimite} ans ({TableauAge[i]} ans) ")
    elif Choix == 3:
        AgeMin = int(input("Entrez l'âge minimum : "))
        AgeMax = int(input("Entrez l'âge maximum : "))
        for i in range(len(TableauAge)):
            if AgeMin <= TableauAge[i] <= AgeMax:
                print(f"{TableauFirstName[i]} {TableauLastName[i]} a un âge compris entre {AgeMin} et {AgeMax} ans ({TableauAge[i]} ans)")
    else:
        print("Choix invalide")

def FiltrageNote(Data):
    DictionnaireNoteEleve = {}
    for student in Data:
        DictionnaireNoteEleve[f"{student.firstname} {student.lastname}"] = student.grades

    print("Choisissez le type de filtrage par Notes :")
    print("1. Filtrer les étudiants ayant une moyenne des Notes supérieure à une certaine Valeur")
    print("2. Filtrer les étudiants ayant une moyenne des Notes inférieure à une certaine Valeur")
    print("3. Filtrer les étudiants ayant au moins une note supérieure à une certaine Valeur")
    print("4. Filtrer les étudiants ayant au moins une note inférieure à une certaine Valeur")

    Choix = int(input("Entrez votre choix : "))

    if Choix == 1:
        Seuil = float(input("Entrez la Valeur de la moyenne minimale : "))
        for Nom, Notes in DictionnaireNoteEleve.items():
            moyenne = sum(Notes) / len(Notes)
            if moyenne > Seuil:
                print(f"{Nom} a une moyenne supérieure à {round(Seuil)}/100 ({round(moyenne)}/100)")
    elif Choix == 2:
        Seuil = float(input("Entrez la Valeur de la moyenne maximale : "))
        for Nom, Notes in DictionnaireNoteEleve.items():
            moyenne = sum(Notes) / len(Notes)
            if moyenne < Seuil:
                print(f"{Nom} a une moyenne inférieure à {round(Seuil)}/100 ({round(moyenne)}/100)")
    elif Choix == 3:
        Valeur = float(input("Entrez la Valeur minimale de la note : "))
        for Nom, Notes in DictionnaireNoteEleve.items():
            if max(Notes) > Valeur:
                print(f"{Nom} a au moins une note supérieure à {Valeur}")
    elif Choix == 4:
        Valeur = float(input("Entrez la Valeur maximale de la note : "))
        for Nom, Notes in DictionnaireNoteEleve.items():
            if min(Notes) < Valeur:
                print(f"{Nom} a au moins une note inférieure à {Valeur}")
    else:
        print("Choix invalide")

