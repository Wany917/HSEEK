from SRC.Statistique import PartieStat

from SRC.Filtrage import FiltrageFirstAndLastName, FiltrageAffichageApprenti, FiltrageAge, FiltrageNote

from SRC.Tri import *

import os

def AfficherMenu():
    print("MENU")
    print("1. Filtrage")
    print("2. Tri")
    print("3. Statistiques")
    print("4. Quitter")

def MenuFiltrage(Data):

    while True:
        print("\nMenu de Filtrage:")
        print("1. Filtrage par prénom et nom")
        print("2. Filtrage par affichage des apprentis")
        print("3. Filtrage par âge")
        print("4. Filtrage par note")
        print("5. Quitter")

        choix = input("Veuillez choisir une option (1-5): ")

        if choix == '1':
            FiltrageFirstAndLastName(Data)
        elif choix == '2':
            FiltrageAffichageApprenti(Data)
        elif choix == '3':
            FiltrageAge(Data)
        elif choix == '4':
            FiltrageNote(Data)
        elif choix == '5':
            print("Au revoir!")
            break
        else:
            print("Option invalide. Veuillez choisir une option valide.")

def MenuTri(data):
    while True:
        print("\nMenu de Tri:")
        print("1. Tri par âge")
        print("2. Tri par nom")
        print("3. Tri par moyenne de notes")
        print("4. Tri par statut d'apprenti")
        print("5. Tri par prénom")
        print("6. Quitter")

        choix = input("Veuillez choisir une option (1-6): ")

        if choix == '1':
            choix_tri = input("Veuillez choisir le type de tri (1: croissant, 2: décroissant): ")
            if choix_tri == '1':
                print("\nTri par âge (croissant):")
                TriParAgeCroissant(data)
            elif choix_tri == '2':
                print("\nTri par âge (décroissant):")
                TriParAgeDecroissant(data)
            else:
                print("Option invalide.")
        elif choix == '2':
            choix_tri = input("Veuillez choisir le type de tri (1: croissant, 2: décroissant): ")
            if choix_tri == '1':
                print("\nTri par nom (croissant):")
                TriParNomCroissant(data)
            elif choix_tri == '2':
                print("\nTri par nom (décroissant):")
                TriParNomDecroissant(data)
            else:
                print("Option invalide.")
        elif choix == '3':
            choix_tri = input("Veuillez choisir le type de tri (1: croissant, 2: décroissant): ")
            if choix_tri == '1':
                print("\nTri par moyenne de notes (croissant):")
                TriParNoteCroissante(data)
            elif choix_tri == '2':
                print("\nTri par moyenne de notes (décroissant):")
                TriParNoteDecroissant(data)
            else:
                print("Option invalide.")
        elif choix == '4':
            choix_tri = input("Veuillez choisir le type de tri (1: croissant, 2: décroissant): ")
            if choix_tri == '1':
                print("\nTri par statut d'apprenti (croissant):")
                TriParStatutApprentiCroissant(data)
            elif choix_tri == '2':
                print("\nTri par statut d'apprenti (décroissant):")
                TriParStatutApprentiDecroissant(data)
            else:
                print("Option invalide.")
        elif choix == '5':
            choix_tri = input("Veuillez choisir le type de tri (1: croissant, 2: décroissant): ")
            if choix_tri == '1':
                print("\nTri par prénom (croissant):")
                TriParPrenomCroissant(data)
            elif choix_tri == '2':
                print("\nTri par prénom (décroissant):")
                TriParPrenomDecroissant(data)
            else:
                print("Option invalide.")
        elif choix == '6':
            print("Au revoir!")
            break
        else:
            print("Option invalide. Veuillez choisir une option valide.")

def MenuStatistique(Data):

    PartieStat(Data)

def LancementMenu(Data):

    os.system('clear')

    while True:

        AfficherMenu()

        Choix = input("Entrez votre choix : ")

        if Choix == "1":

            MenuFiltrage(Data)
        elif Choix == "2":
            MenuTri(Data)
        elif Choix == "3":
            MenuStatistique(Data)
        elif Choix == "4":
            print("Merci d'avoir utilisé le programme. Au revoir !")
            break
        else:
            print("Choix invalide. Veuillez entrer un choix valide.")