def TriParAgeCroissant(data):
    sorted_students = sorted(data, key=lambda student: student.age)
    print("Tri par âge:")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname} - Age: {student.age}")

def TriParNomCroissant(data):
    sorted_students = sorted(data, key=lambda student: student.lastname)
    print("Tri par nom:")
    for student in sorted_students:
        print(f"{student.lastname} {student.firstname}")

def MoyenneNotesCroissant(student):
    return sum(student.grades) / len(student.grades)

def TriParNoteCroissante(data):
    print("Tri par note (croissante):")
    sorted_students = sorted(data, key=lambda student: sum(student.grades) / len(student.grades))
    for student in sorted_students:
        moyenne_notes = sum(student.grades) / len(student.grades)
        print(f"{student.firstname} {student.lastname} - Moyenne des notes: {round(moyenne_notes)}/100")

def TriParStatutApprentiCroissant(data):
    sorted_students = sorted(data, key=lambda student: not student.apprentice)
    print("Tri par statut d'apprenti:")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname} - Apprenti: {student.apprentice}")

def TriParPrenomCroissant(data):
    sorted_students = sorted(data, key=lambda student: student.firstname)
    print("Tri par prénom:")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname}")

def TriParAgeDecroissant(data):
    sorted_students = sorted(data, key=lambda student: student.age, reverse=True)
    print("Tri par âge (décroissant):")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname} - Age: {student.age}")

def TriParNomDecroissant(data):
    sorted_students = sorted(data, key=lambda student: student.lastname, reverse=True)
    print("Tri par nom (décroissant):")
    for student in sorted_students:
        print(f"{student.lastname} {student.firstname}")

def TriParNoteDecroissant(data):
    print("Tri par note (décroissant):")
    sorted_students = sorted(data, key=lambda student: sum(student.grades) / len(student.grades), reverse=True)
    for student in sorted_students:
        moyenne_notes = sum(student.grades) / len(student.grades)
        print(f"{student.firstname} {student.lastname} - Moyenne des notes: {round(moyenne_notes)}/100")

def TriParStatutApprentiDecroissant(data):
    sorted_students = sorted(data, key=lambda student: not student.apprentice, reverse=True)
    print("Tri par statut d'apprenti (décroissant):")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname} - Apprenti: {student.apprentice}")

def TriParPrenomDecroissant(data):
    sorted_students = sorted(data, key=lambda student: student.firstname, reverse=True)
    print("Tri par prénom (décroissant):")
    for student in sorted_students:
        print(f"{student.firstname} {student.lastname}")
