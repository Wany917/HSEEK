class Student:
    def __init__(self, FirstName: str, LastName: str, Age: int, Apprentice: bool, Grades: list[int]):
        self.firstname = FirstName
        self.lastname = LastName
        self.age = Age
        self.apprentice = Apprentice
        self.grades = Grades