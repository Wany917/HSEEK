from .CLASS import Student
import json
import xml.etree.ElementTree as ET
import yaml
import csv

def LoadJSON(FILE):
    with open(FILE, 'r') as jsonfile:
        data = json.load(jsonfile)
    return [Student(StudentData['firstName'], StudentData['lastName'], StudentData['age'], StudentData['apprentice'], StudentData['grades'] if isinstance(StudentData['grades'], list) else [StudentData['grades']]) for StudentData in data]

def LoadXML(FILE):
    Location = ET.parse(FILE)
    root = Location.getroot()
    Students = []
    for StudentElement in root.findall('student'):
        FirstName = StudentElement.find('firstname').text
        LastName = StudentElement.find('lastName').text
        Age = int(StudentElement.find('age').text)
        Apprentice = StudentElement.find('apprentice').text.lower() == 'true'
        grades = [int(grade.text) for grade in StudentElement.find('grades')]
        Students.append(Student(FirstName, LastName, Age, Apprentice, grades))
    return Students

def LoadYAML(FILE):
    with open(FILE, 'r') as file:
        data = yaml.safe_load(file)
    Students = []
    for StudentEntry in data['Students']:
        StudentData = StudentEntry['student']
        FirstName = StudentData['firstanme']
        LastName = StudentData['lastname']
        Age = StudentData['age']
        Apprentice = StudentData['apprentice']
        grades = [grade_entry['grade'] for grade_entry in StudentData['grades']]
        Students.append(Student(FirstName, LastName, Age, Apprentice, grades))
    return Students

def LoadCSV(FILE):
    with open(FILE, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        return [Student(row['firstname'], row['lastname'], int(row['age']), row['apprentice'].lower() == 'true', [int(grade.strip()) for grade in row['grades'].split(',')]) for row in reader]
