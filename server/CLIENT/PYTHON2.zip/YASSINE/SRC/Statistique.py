def CalculStat(Etudiant ,MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool):

    # Stat pour age 

    NombreTotalAge = NombreTotalAge + 1

    if(MinAge > Etudiant.age):

        MinAge = Etudiant.age
    
    if(MaxAge < Etudiant.age):

        MaxAge = Etudiant.age
    
    AgeTotal = AgeTotal + Etudiant.age
    
    # Stat pour les notes

    NombreTotalDeNote = NombreTotalDeNote + len(Etudiant.grades)

    for i in range(len(Etudiant.grades)):

        NoteTotal = NoteTotal + Etudiant.grades[i]

        if(MinNote > Etudiant.grades[i]):

            MinNote = Etudiant.grades[i]
        
        if(MaxNote < Etudiant.grades[i]):

            MaxNote = Etudiant.grades[i]

    # Stat pour le nombre d'apprenti

    if(Etudiant.apprentice == True):

        NombreDeTrue = NombreDeTrue + 1
    
    NombreTotalDeBool = NombreTotalDeBool + 1

    return Etudiant ,MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool,

def AffichageStat(MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool):

    print("      PARTIE STAT          \n")

    print("STATS AGE")
    print(f"Min Age     : {MinAge}")
    print(f"Max Age     : {MaxAge}")
    print(f"Moyenne Age : {round(AgeTotal / NombreTotalAge)}")


    print("\nPOURCENTAGE D'APPRENTI")
    print(f"Pourcentage d'apprenti {round((NombreDeTrue / NombreTotalDeBool) * 100)}%")
    print(f"Pourcentage de non apprenti :{round(((NombreTotalDeBool - NombreDeTrue) / NombreTotalDeBool)* 100)}%")

    print("\nSTATS NOTE")
    print(f"Min Note     : {MinNote}/100")
    print(f"Max Note     : {MaxNote}/100")
    print(f"Moyenne Note : {round(NoteTotal / NombreTotalDeNote)}/100")

def PartieStat(data):

    # Variables Age
    MinAge = 100
    MaxAge = 0
    AgeTotal = 0
    NombreTotalAge = 0

    # Variable Note
    NoteTotal = 0
    MinNote = 200
    MaxNote = -1
    NombreTotalDeNote = 0

    # Variable Apprentice
    NombreDeTrue = 0
    NombreTotalDeBool = 0

    for student in data:

        Etudiant = student

        Etudiant, MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool = CalculStat(Etudiant, MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool)


    AffichageStat(MinAge, MaxAge, AgeTotal, NombreTotalAge, NoteTotal, MinNote, MaxNote, NombreTotalDeNote, NombreDeTrue, NombreTotalDeBool)